import java.util.Scanner;

public class TrataComando {

	// Scanner sc = new Scanner(System.in);
	Imagem imagem;
	Cor cor;

	public void TrataComandoImagem(Scanner sc) {
		System.out.println("Comando Imagem");

		int larg = sc.nextInt();
		int altu = sc.nextInt();
		// String type = sc.next();
		System.out.print("Criando imagem " + larg + " por " + altu);

		this.imagem = new Imagem(altu, larg);
	}

	public void TrataComandoReta(Scanner sc) {
		System.out.println("Comando Reta");

		int xA = sc.nextInt();
		int yA = sc.nextInt();
		int xB = sc.nextInt();
		int yB = sc.nextInt();

		Ponto pA = new Ponto(xB, yB);
		Ponto pB = new Ponto(xB, yB);

		Reta reta = new Reta();
		reta.setVertices(pA, pB);
		reta.draw(this.imagem, new Cor());
		
		System.out.println("FIM RETA");
	}

	public void TrataComandoRetangulo(Scanner sc) {
		System.out.println("Comando Retangulo");

		int xA = sc.nextInt();
		int yA = sc.nextInt();
		int xB = sc.nextInt();
		int yB = sc.nextInt();

		Ponto pA = new Ponto(xA, yA);
		Ponto pB = new Ponto(xB, yB);

		Retangulo regl = new Retangulo();
		regl.setVertices(pA, pB);
		System.out.println("FIM RETANGULO");
	}

	public void TrataComandoTriangulo(Scanner sc) {
		System.out.println("Comando Triangulo");

		int xA = sc.nextInt();
		int yA = sc.nextInt();
		int xB = sc.nextInt();
		int yB = sc.nextInt();
		int xC = sc.nextInt();
		int yC = sc.nextInt();

		Ponto pA = new Ponto(xA, yA);
		Ponto pB = new Ponto(xB, yB);
		Ponto pC = new Ponto(xC, yC);

		Triangulo tria = new Triangulo();
		tria.setVertices(pA, pB, pC);
		System.out.println("FIM TRIANGULO");
	}

	public void TrataComandoCirculo(Scanner sc) {
		System.out.println("Comando Circulo");

		int xA = sc.nextInt();
		int yA = sc.nextInt();
		int raio = sc.nextInt();

		Ponto pA = new Ponto(xA, yA);

		Circulo circ = new Circulo();
		circ.setCentro(pA);
		System.out.println("FIM CIRCULO");
	}

	public void TrataComandoInvalido(Scanner sc) {
		System.out.println("Comando Invalido");
	}

	public void TrataComandoCor(Scanner sc) {
		System.out.println("Comando Cor");

		int r = 0;
		int g = 0;
		int b = 0;
		int c = 0;

  		c = sc.nextInt();
		
/*
  		r = sc.nextInt();
  		g = sc.nextInt();
		b = sc.nextInt();
		
		this.cor = new Cor();
		try{
			this.cor.setVermelho(r);
		}
		catch(Exception e){  
	         System.out.println(e.getMessage());  
		}	
		
		try{
			this.cor.setVerde(g);
		}
		catch(Exception e){  
	         System.out.println(e.getMessage());  
		}	
		try{
			this.cor.setAzul(b);
		}
		catch(Exception e){  
	         System.out.println(e.getMessage());  
		}	
*/
		try{
			cor.setCinza(c);
		}
		catch(Exception e){  
	         System.out.println(e.getMessage());  
		}	
	}

	public void TrataComandoSalvar(Scanner sc) {
		System.out.println("Comando Salvar");
		try{
			this.imagem.Salvar();
		}
		catch(Exception e){  
	         System.out.println(e.getMessage());  
		}	
	}
}