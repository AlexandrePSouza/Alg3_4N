import java.io.*;
public class Retangulo extends Shape{
	
	private Ponto pA = new Ponto(0,0);
	private Ponto pB = new Ponto(0,0);
	private Ponto pC = new Ponto(0,0);
	private Ponto pD = new Ponto(0,0);
	
	public void Retangulo() {
		System.out.println("Retangulo*******************");
	}

	public void setVertices(Ponto pA, Ponto pC){
		this.pA = pA;
		this.pB = new Ponto(pA.getX(), pC.getY());
		this.pC = pC;
		this.pD = new Ponto(pC.getX(), pA.getY());
	}
	
	public void draw(Imagem img, Cor c) {
		Reta r1 = new Reta();
		r1.setVertices(pA, pB);
		r1.draw(this.img, new Cor());

		Reta r2 = new Reta();
		r2.setVertices(pB, pC);
		r2.draw(this.img, new Cor());

		Reta r3 = new Reta();
		r3.setVertices(pC, pD);
		r3.draw(this.img, new Cor());

		Reta r4 = new Reta();
		r4.setVertices(pD, pA);
		r4.draw(this.img, new Cor());
	}	
}
