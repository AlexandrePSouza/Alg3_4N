
public class Reta extends Shape {

	private Ponto pA = new Ponto(0,0);
	private Ponto pB = new Ponto(0,0);
	private Ponto pT = new Ponto(0,0);

	public void Reta() {
		System.out.println("Reta++++++++++++++++++++++++++++++++++++++++++");
	}

	public void setVertices(Ponto pA, Ponto pB) {
		this.pA = pA;
		this.pB = pB;
	}

	public void draw(Imagem img, Cor c) {
		img.setPixel(pA, c);
		img.setPixel(pB, c);

		int x = pA.x;
		int y = pA.y;
		int variacaoX = Math.abs(pB.x - pA.x);
		int variacaoY = Math.abs(pB.y - pA.y);
		int erro = 0;

		if ((variacaoY >= variacaoX && pA.y > pB.y) || (variacaoY < variacaoX && variacaoY < 0)) {
			x = pB.x;
			y = pB.y;
			variacaoX = Math.abs(pA.x - pB.x);
			variacaoY = Math.abs(pA.y - pB.y);
			}

		if (variacaoX >= 0) {
			if (variacaoX >= variacaoY) {
				for (int i = 1; i < variacaoX; i++) {
					if (erro < 0) {
						x++;
						pT.x = x;
						pT.y = y;
						img.setPixel(pT, c);
						erro += variacaoY;
					} else {
						x++;
						y++;
						pT.x = x;
						pT.y = y;
						img.setPixel(pT, c);
						erro += variacaoY - variacaoX;
					}
				}
			} else {
				for (int i = 1; i < variacaoY; i++) {
					if (erro < 0) {
						x++;
						y++;
						pT.x = x;
						pT.y = y;
						img.setPixel(pT, c);
						erro += variacaoY - variacaoX;
					} else {
						y++;
						pT.x = x;
						pT.y = y;
						img.setPixel(pT, c);
						erro -= variacaoX;
					}
				}
			}
		} else {
			if (variacaoX >= variacaoY) {
				for (int i = 1; i < variacaoX; i++) {
					if (erro < 0) {
						x--;
						pT.x = x;
						pT.y = y;
						img.setPixel(pT, c);
						erro += variacaoY;
					} else {
						x--;
						y++;
						pT.x = x;
						pT.y = y;
						img.setPixel(pT, c);
						erro += variacaoY + variacaoX;
					}
				}
			} else {
				for (int i = 1; i < variacaoY; i++) {
					if (erro < 0) {
						x--;
						y++;
						pT.x = x;
						pT.y = y;
						img.setPixel(pT, c);
						erro += variacaoY + variacaoX;
					} else {
						y++;
						pT.x = x;
						pT.y = y;
						img.setPixel(pT, c);
						erro += variacaoX;
					}
				}
			}
		}
	}
}