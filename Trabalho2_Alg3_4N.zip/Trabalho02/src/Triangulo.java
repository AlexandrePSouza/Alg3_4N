import java.io.*;

public class Triangulo extends Shape {

	private Ponto pA = new Ponto(0, 0);
	private Ponto pB = new Ponto(0, 0);
	private Ponto pC = new Ponto(0, 0);

	public void Triangulo() {
		System.out.println("Triangulo-----------------------");
	}

	public void setVertices(Ponto pA, Ponto pB, Ponto pC) {
		this.pA = pA;
		this.pB = pB;
		this.pC = pC;
	}
	
	public void draw(Imagem img, Cor c) {
		Reta r1 = new Reta();
		r1.setVertices(pA, pB);
		r1.draw(this.img, new Cor());

		Reta r2 = new Reta();
		r2.setVertices(pB, pC);
		r2.draw(this.img, new Cor());

		Reta r3 = new Reta();
		r3.setVertices(pC, pA);
		r3.draw(this.img, new Cor());
	}
}
