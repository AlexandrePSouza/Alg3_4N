public abstract class Shape  {
		protected Imagem img;
		protected Cor cor;

//		public void Shape(Imagem img) {
//		}

		public void draw(Imagem img, Cor c) {
			
		}
		public void setCor(Cor c){
			
		}
	}
