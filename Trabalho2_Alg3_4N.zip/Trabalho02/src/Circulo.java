import java.io.*;
public class Circulo extends Shape{
	
	private Ponto pC = new Ponto(0, 0);
	private Ponto pZ = new Ponto(0, 0);
	private int raio;
	
	public void Circulo() {
		System.out.println("Circulo");
	}
	
	public void setCentro(Ponto pC){
		this.pC = pC;
	}
	public void setRaio(int raio){
		this.raio = raio;
	}
	
	public void draw( Cor c, Imagem img ) {
		int x = 0;
	    int y = this.raio;
	    int u = 1;
	    int v = 2 * this.raio - 1;
	    int E = 0;
		
		while ( x < y ) {
			
			pZ.x = pC.x + x;
			pZ.y = pC.y + y;
			img.setPixel( pZ, c );

			pZ.x = pC.x + y;
			pZ.y = pC.y - x;
			img.setPixel( pZ, c );

			pZ.x = pC.x - x;
			pZ.y = pC.y - y;
			img.setPixel( pZ, c );

			pZ.x = pC.x - y;
			pZ.y = pC.y + x;
			img.setPixel( pZ, c );

		    x++; E += u; u += 2;

		    if (v < 2 * E){
		    	y--; 
		    	E -= v; 
		    	v -= 2;
		    }
		    if (x > y) 
		    	break;

			pZ.x = pC.x + y;
			pZ.y = pC.y + x;
			img.setPixel( pZ, c );

			pZ.x = pC.x + x;
			pZ.y = pC.y - y;
			img.setPixel( pZ, c );
		    
			pZ.x = pC.x - y;
			pZ.y = pC.y - x;
			img.setPixel( pZ, c );

			pZ.x = pC.x - x;
			pZ.y = pC.y + y;
			img.setPixel( pZ, c );
		}
	}
}