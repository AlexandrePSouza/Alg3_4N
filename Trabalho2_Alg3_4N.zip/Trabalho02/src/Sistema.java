import java.util.Scanner;

public class Sistema {
	// private static Scanner sc = new Scanner(System.in);
	// private static Imagem imagem;
	// private static Cor cor;
	// private String nomeArquivo;

	Imagem imagem;
	Cor cor = new Cor();
	
	public static void main(String[] args) {

		String cmd = "";
		Scanner sc = new Scanner(System.in);
		
		System.out.println("\n Digite um comando: ");
		TrataComando tc = new TrataComando();

		while(sc.hasNext()){
			cmd = sc.next().toLowerCase(); //passar para minusculo

			
			switch (cmd) {
				case "fim":
					System.exit(0);
				case "imagem": 
					tc.TrataComandoImagem(sc);
					break;
				case "salvar":
					tc.TrataComandoSalvar(sc);
					break;
				case "circulo":
					tc.TrataComandoCirculo(sc);
					break;
				case "cor":
					tc.TrataComandoCor(sc);
					break;
				case "reta":
					tc.TrataComandoReta(sc);
					break;
				case "retangulo":
					tc.TrataComandoRetangulo(sc);
					break;
				case "triangulo":
					tc.TrataComandoTriangulo(sc);
					break;
				default:
					//tratacomandoInvalido();
			}
		}		
	}
}
	
