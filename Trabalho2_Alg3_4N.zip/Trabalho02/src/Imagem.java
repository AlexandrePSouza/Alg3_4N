import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Scanner;

public class Imagem {

	private int[][] img;
	private int cores = 1;

	public Imagem(int altura, int largura) {
		this.img = new int[altura][largura];
		// this.tipoCor = tipoCor;

		for (int x = 0; x < altura; x++) {
			for (int y = 0; y < largura; y++) {
				img[x][y] = 0;
			}
		}
	}

	public void setPixel(Ponto p, Cor c) {
		img[p.x][p.y] = c.getCinza();
	}
	
	public void addShape(Shape shape, Cor cor){
		//shape.setCor(cor);
		shape.draw(this, cor);
	}
	
	public void Salvar( ) throws IOException {
		BufferedWriter out = new BufferedWriter( new FileWriter("c://teste//imagem.pnm") );

		if ( this.cores == 1 ){
			out.write(String.format("P2\n%d %d\n255\n", img[0].length, img[0].length ));
		} else {
			out.write(String.format("P3\n%d %d\n255\n", img[0].length, img[0].length ));
		}
	
		for (int[] linha : img) {
			for (int v : linha){
				out.write(String.format("%d ", v) );
			}
		}	
		out.close();
	}		
}
