import java.io.IOException;

public class Cor {

	private int vermelho;
	private int verde;
	private int azul;
	private int cinza;

/*
  	public Cor(int vermelho, int verde, int azul) {
 
		this.vermelho = vermelho;
		this.verde = verde;
		this.azul = azul;
	}

	public Cor(int cinza) {
		this.cinza = cinza;
	}
*/
	public Cor() {
//		this.cinza = 255;
	}

	//------------------------
	public void setVermelho(int vermelho) throws Exception{
        if ((vermelho < 1) || (vermelho > 255)){
            throw new Exception ("Valor Vermelho invalido"); 
            }
        else{
            this.vermelho = vermelho;
            }
        }               

	public void setVerde(int verde)  throws Exception{
        if ((verde < 1) || (verde > 255)){
            throw new Exception ("Valor Verde invalido"); 
            }
        else{
            this.verde = verde;
            }
        }    

	public void setAzul(int azul)  throws Exception{
        if ((azul < 1) || (azul > 255)){
            throw new Exception ("Valor Azul invalido"); 
            }
        else{
            this.azul = azul;
            }
        }    
	public void setCinza(int cinza)  throws Exception{

System.out.print("2"+cinza);
		if ((cinza < 1) || (cinza > 255)){
       	
            throw new Exception ("Valor Cinza invalido"); 
            }
        else{
            this.cinza = cinza;
            }
        }    

	//------------------------
	public int getVermelho() {
		return this.vermelho;
	}

	public int getVerde() {
		return this.verde;
	}

	public int getAzul() {
		return this.azul;
	}

	public int getCinza() {
		return this.cinza;
	}
}